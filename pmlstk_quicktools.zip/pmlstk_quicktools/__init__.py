bl_info = {
    "name": "pommelstrike quick tools",
    "blender": (3, 8, 0),  # Updated for Blender 3.8
    "version": (2, 5, 18),  # Incremented version
    "category": "Object",
}

import bpy
import mathutils
from mathutils import Vector  # Alias for clarity

# X-offset adjustment value
X_OFFSET = 0.14

# Main Panel
class pommelstrike_PT_main_panel(bpy.types.Panel):
    bl_label = "pommelstrike quick tools"
    bl_idname = "pommelstrike_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "pommelstrike"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.quick_update_mesh_nomenclature")
        layout.operator("mesh.calculate_bounds")
        layout.operator("mesh.copy_bounds_to_clipboard", text="Copy Bounds to Clipboard")
        
        layout.label(text="Mesh Bounds Info:")
        layout.label(text=f"Bounds Max: {context.scene.mesh_bounds_max}")
        layout.label(text=f"Bounds Min: {context.scene.mesh_bounds_min}")
        layout.label(text=f"Center: {context.scene.mesh_bounds_center}")

# Calculate Mesh Bounds Operator
class MESH_OT_CalculateBounds(bpy.types.Operator):
    bl_idname = "mesh.calculate_bounds"
    bl_label = "Calculate Mesh Bounds"
    bl_description = "Calculate the bounds (max, min, center, radius) of the selected mesh with Z-up to Y-up rotation and X-offset adjustment"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def calculate_bounds_with_rotation(obj):
        """Calculate the min, max, center, and radius of a 3D mesh with Z-up to Y-up rotation and X-offset adjustment."""
        if obj.type != 'MESH':
            return None

        # Convert all vertex coordinates to global space
        vertices = [obj.matrix_world @ v.co for v in obj.data.vertices]
        
        # Apply the Z-up to Y-up rotation
        rotated_vertices = [
            Vector((v.x, v.z, -v.y))  # Rotate around X-axis
            for v in vertices
        ]

        # Calculate min and max bounds using the rotated vertices
        min_bound = Vector((
            round(min(v.x for v in rotated_vertices) - X_OFFSET, 2),  # Adjust for X-offset
            round(min(v.y for v in rotated_vertices), 2),
            round(min(v.z for v in rotated_vertices), 2),
        ))
        max_bound = Vector((
            round(max(v.x for v in rotated_vertices) - X_OFFSET, 2),  # Adjust for X-offset
            round(max(v.y for v in rotated_vertices), 2),
            round(max(v.z for v in rotated_vertices), 2),
        ))

        # Calculate the center
        center = (min_bound + max_bound) / 2
        center = Vector((
            round(center.x, 2),
            round(center.y, 2),
            round(center.z, 2),
        ))

        # Calculate the radius
        radius = round(max((max_bound - center).length, (center - min_bound).length), 2)

        return max_bound, min_bound, center, radius

    def execute(self, context):
        obj = context.object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a Mesh Object")
            return {'CANCELLED'}
        
        bounds = self.calculate_bounds_with_rotation(obj)
        if bounds:
            max_bound, min_bound, center, radius = bounds

            # Format vectors without "Vector" and parentheses
            max_bound_display = f"{max_bound.x:.2f} {max_bound.y:.2f} {max_bound.z:.2f}"
            min_bound_display = f"{min_bound.x:.2f} {min_bound.y:.2f} {min_bound.z:.2f}"
            center_display = f"{center.x:.2f} {center.y:.2f} {center.z:.2f}"

            context.scene.mesh_bounds_max = max_bound_display
            context.scene.mesh_bounds_min = min_bound_display
            context.scene.mesh_bounds_center = center_display
            context.scene.mesh_radius = f"{radius:.2f}"  # Store radius as a string
        else:
            self.report({'ERROR'}, "Could not calculate bounds")
            return {'CANCELLED'}
        
        return {'FINISHED'}

# Copy Bounds to Clipboard Operator
class MESH_OT_CopyBoundsToClipboard(bpy.types.Operator):
    bl_idname = "mesh.copy_bounds_to_clipboard"
    bl_label = "Copy Bounds to Clipboard"
    bl_description = "Copy the calculated mesh bounds to the clipboard"
    bl_options = {"REGISTER"}

    def execute(self, context):
        # Get the bounds information from the scene
        max_bound = context.scene.mesh_bounds_max
        min_bound = context.scene.mesh_bounds_min
        center = context.scene.mesh_bounds_center
        radius = context.scene.mesh_radius

        # Reformat strings for clipboard output
        bounds_info = (
            f'<attribute id="BoundsMax" type="fvec3" value="{max_bound}" />\n'
            f'<attribute id="BoundsMin" type="fvec3" value="{min_bound}" />\n'
            f'<attribute id="Center" type="fvec3" value="{center}" />\n'
            f'<attribute id="Radius" type="float" value="{radius}" />'
        )

        # Copy to clipboard using Blender's built-in functionality
        bpy.context.window_manager.clipboard = bounds_info
        self.report({'INFO'}, "Bounds copied to clipboard!")

        return {'FINISHED'}

# Update Mesh Nomenclature Operator (Unchanged)
class OBJECT_OT_QuickUpdateMeshNomenclature(bpy.types.Operator):
    bl_idname = "object.quick_update_mesh_nomenclature"
    bl_label = "Update Mesh Nomenclature"
    bl_description = "Match the mesh data name to the object name"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def execute(self, context):
        active_object = context.active_object
        if active_object:
            for obj in context.selected_objects:
                obj.data.name = active_object.name
        else:
            print("No active object selected.")
        return {"FINISHED"}

# Registration
classes = [
    pommelstrike_PT_main_panel,
    OBJECT_OT_QuickUpdateMeshNomenclature,
    MESH_OT_CalculateBounds,
    MESH_OT_CopyBoundsToClipboard,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mesh_bounds_min = bpy.props.StringProperty(name="Min Bound", default="N/A")
    bpy.types.Scene.mesh_bounds_max = bpy.props.StringProperty(name="Max Bound", default="N/A")
    bpy.types.Scene.mesh_bounds_center = bpy.props.StringProperty(name="Center", default="N/A")
    bpy.types.Scene.mesh_radius = bpy.props.StringProperty(name="Radius", default="N/A")

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.mesh_bounds_min
    del bpy.types.Scene.mesh_bounds_max
    del bpy.types.Scene.mesh_bounds_center
    del bpy.types.Scene.mesh_radius

if __name__ == "__main__":
    register()
